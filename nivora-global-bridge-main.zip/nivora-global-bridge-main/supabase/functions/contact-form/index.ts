import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface ContactFormRequest {
  name: string;
  contact_number: string;
  email: string;
  message: string;
}

const handler = async (req: Request): Promise<Response> => {
  console.log("Contact form handler started");
  
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { name, contact_number, email, message }: ContactFormRequest = await req.json();
    
    console.log("Received contact form submission:", { name, email, contact_number });

    // Validate required fields
    if (!name || !contact_number || !email || !message) {
      return new Response(
        JSON.stringify({ error: "All fields are required" }),
        {
          status: 400,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return new Response(
        JSON.stringify({ error: "Invalid email format" }),
        {
          status: 400,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    // Initialize Supabase client
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Insert contact submission into database
    const { data: submission, error: dbError } = await supabase
      .from("contact_submissions")
      .insert({
        name,
        contact_number,
        email,
        message,
      })
      .select()
      .single();

    if (dbError) {
      console.error("Database error:", dbError);
      return new Response(
        JSON.stringify({ error: "Failed to save contact submission" }),
        {
          status: 500,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    console.log("Contact submission saved to database:", submission.id);

    // Send email notification to admin
    const adminEmailResponse = await resend.emails.send({
      from: "Nivora Global <noreply@nivoraglobal.com>",
      to: ["renjithsurendrant@gmail.com"],
      subject: "New Contact Form Submission - Nivora Global",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #1a365d; border-bottom: 2px solid #ffd700; padding-bottom: 10px;">
            New Contact Form Submission
          </h2>
          
          <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #2d3748; margin-top: 0;">Contact Details:</h3>
            <p><strong>Name:</strong> ${name}</p>
            <p><strong>Email:</strong> ${email}</p>
            <p><strong>Contact Number:</strong> ${contact_number}</p>
          </div>
          
          <div style="background-color: #fff5f5; padding: 20px; border-radius: 8px; border-left: 4px solid #ffd700;">
            <h3 style="color: #2d3748; margin-top: 0;">Message:</h3>
            <p style="line-height: 1.6;">${message}</p>
          </div>
          
          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e2e8f0; color: #718096; font-size: 14px;">
            <p>Submitted at: ${new Date().toLocaleString()}</p>
            <p>Submission ID: ${submission.id}</p>
          </div>
        </div>
      `,
    });

    console.log("Admin email sent:", adminEmailResponse);

    // Send auto-reply confirmation email to user
    const userEmailResponse = await resend.emails.send({
      from: "Nivora Global <noreply@nivoraglobal.com>",
      to: [email],
      subject: "Thank you for contacting Nivora Global",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: #1a365d; margin-bottom: 10px;">Nivora Global</h1>
            <div style="width: 50px; height: 3px; background-color: #ffd700; margin: 0 auto;"></div>
          </div>
          
          <h2 style="color: #2d3748;">Thank you for contacting us, ${name}!</h2>
          
          <p style="color: #4a5568; line-height: 1.6; font-size: 16px;">
            We have received your message and appreciate your interest in our premium Kerala spices 
            and global trading services.
          </p>
          
          <div style="background-color: #f0fff4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #ffd700;">
            <p style="color: #2d3748; margin: 0; font-weight: 600;">
              Our team will review your inquiry and get back to you within 24-48 hours.
            </p>
          </div>
          
          <p style="color: #4a5568; line-height: 1.6;">
            In the meantime, feel free to explore our premium spice collections and learn more about 
            our authentic Kerala spices sourced directly from local farmers.
          </p>
          
          <div style="margin: 30px 0; padding: 20px; background-color: #f8f9fa; border-radius: 8px;">
            <h3 style="color: #2d3748; margin-top: 0;">Contact Information:</h3>
            <p style="color: #4a5568; margin: 5px 0;"><strong>Email:</strong> info@nivoraglobal.com</p>
            <p style="color: #4a5568; margin: 5px 0;"><strong>UK:</strong> +44 7532624042</p>
            <p style="color: #4a5568; margin: 5px 0;"><strong>India:</strong> +91 9446205777</p>
            <p style="color: #4a5568; margin: 5px 0;"><strong>Website:</strong> www.nivoraglobal.com</p>
          </div>
          
          <div style="text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #e2e8f0;">
            <p style="color: #718096; font-size: 14px; margin: 0;">
              Best regards,<br>
              <strong>The Nivora Global Team</strong>
            </p>
          </div>
        </div>
      `,
    });

    console.log("User confirmation email sent:", userEmailResponse);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: "Thank you for contacting us. Our team will get back to you soon.",
        submissionId: submission.id 
      }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders,
        },
      }
    );
  } catch (error: any) {
    console.error("Error in contact form handler:", error);
    return new Response(
      JSON.stringify({ 
        error: "An error occurred while processing your request. Please try again." 
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);