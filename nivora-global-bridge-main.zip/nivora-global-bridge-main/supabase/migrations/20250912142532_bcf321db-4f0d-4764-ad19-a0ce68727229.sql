-- Remove the overly permissive admin policy
DROP POLICY IF EXISTS "Admin can view all submissions" ON public.contact_submissions;

-- Create a more secure policy that only allows service role access
-- This prevents unauthorized access while still allowing backend operations
CREATE POLICY "Service role can manage submissions" 
ON public.contact_submissions 
FOR ALL 
USING (auth.role() = 'service_role');

-- Keep the public insert policy for form submissions
-- (This was already secure)