import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import keralaPlantation from "@/assets/kerala-spice-plantation.jpg";

const Hero = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background Image */}
      <div 
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url(${keralaPlantation})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat'
        }}
      ></div>
      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-black/70 z-10"></div>
      
      {/* Content */}
      <div className="relative z-20 text-center px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="animate-fade-in">
          <h1 className="font-roboto text-6xl md:text-8xl lg:text-9xl font-bold text-white mb-8 leading-[0.9] tracking-tight">
            From Kerala's Spice Gardens
            <br />
            <span className="text-gold">to the World</span>
          </h1>
          
          <div className="w-24 h-1 bg-gold mx-auto mb-8"></div>
          
          <p className="font-inter text-2xl md:text-3xl text-gold/90 mb-6 font-light tracking-wide">
            Authentic Indian Spices | Kerala to London
          </p>
          
          <p className="font-inter text-xl text-white/75 mb-16 max-w-3xl mx-auto leading-relaxed font-light">
            Connecting Kerala's authentic spice heritage with global markets through premium exports of black pepper, cardamom, turmeric, and more.
          </p>
          
          <Button 
            size="lg" 
            className="bg-gold text-gold-foreground hover:bg-gold/90 shadow-gold font-inter font-semibold text-xl px-16 py-8 group rounded-full transition-all duration-300 hover:scale-105"
          >
            Explore Premium Spices
            <ArrowRight className="ml-3 h-6 w-6 group-hover:translate-x-2 transition-transform duration-300" />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Hero;