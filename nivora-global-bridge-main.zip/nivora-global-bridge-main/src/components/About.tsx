const About = () => {
  return (
    <section id="about" className="py-32 bg-primary">
      <div className="container mx-auto px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="font-roboto text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight">
            About Nivora Global Ltd
          </h2>
          <div className="w-32 h-1 bg-gold mx-auto mb-6"></div>
          <p className="font-inter text-xl text-white/80 max-w-3xl mx-auto font-light">
            Connecting Kerala's authentic spice heritage with global markets
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16">
            <div className="relative bg-white/10 backdrop-blur-sm rounded-3xl p-12 border border-white/20 shadow-lg">
              <div className="text-5xl mb-6">🎯</div>
              <h3 className="font-roboto text-4xl font-bold text-gold mb-6">
                Our Mission
              </h3>
              <p className="font-inter text-lg text-white/90 leading-relaxed">
                To connect Kerala's finest spices with global markets through trust, quality, and sustainable partnerships. We specialize in sourcing premium black pepper, cardamom, turmeric, and other authentic spices directly from Kerala's traditional farms.
              </p>
            </div>
            
            <div className="relative bg-white/10 backdrop-blur-sm rounded-3xl p-12 border border-white/20 shadow-lg">
              <div className="text-5xl mb-6">🌟</div>
              <h3 className="font-roboto text-4xl font-bold text-gold mb-6">
                Our Vision
              </h3>
              <p className="font-inter text-lg text-white/90 leading-relaxed">
                To become the world's most trusted bridge between Kerala's spice gardens and international markets. We envision being recognized globally for delivering the purest, most authentic Kerala spices while supporting local farmers and sustainable agriculture practices.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;