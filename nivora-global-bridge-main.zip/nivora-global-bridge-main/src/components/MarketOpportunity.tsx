import { TrendingUp, Users, MapPin, DollarSign } from "lucide-react";

const MarketOpportunity = () => {
  const stats = [
    {
      icon: DollarSign,
      value: "£24.5B",
      label: "UK-India Trade Volume",
      description: "Annual bilateral trade showing consistent growth"
    },
    {
      icon: Users,
      value: "1.5M",
      label: "Indian Diaspora in UK", 
      description: "Growing community seeking authentic products"
    },
    {
      icon: TrendingUp,
      value: "15%",
      label: "Annual Growth Rate",
      description: "Increasing demand for premium Indian goods"
    },
    {
      icon: MapPin,
      value: "50+",
      label: "Distribution Centers",
      description: "Strategic locations across major UK cities"
    }
  ];

  return (
    <section className="py-20 bg-primary text-white relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div 
          className="w-full h-full"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23D4AF37' fill-opacity='0.1' fill-rule='evenodd'%3E%3Cpath d='M20 20c0 11.046-8.954 20-20 20v20h40V20H20z'/%3E%3C/g%3E%3C/svg%3E")`,
          }}
        ></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold mb-6">
            Market Opportunity
          </h2>
          <div className="w-20 h-1 bg-gold mx-auto mb-6"></div>
          <p className="font-lato text-lg text-white/90 max-w-3xl mx-auto">
            The UK market presents unprecedented opportunities for premium Indian products, 
            driven by cultural appreciation and growing consumer sophistication
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div 
              key={index} 
              className="text-center animate-slide-up"
              style={{animationDelay: `${index * 150}ms`}}
            >
              <div className="w-20 h-20 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <stat.icon className="h-10 w-10 text-gold" />
              </div>
              
              <div className="font-playfair text-4xl font-bold text-gold mb-2">
                {stat.value}
              </div>
              
              <h3 className="font-lato text-xl font-semibold mb-3">
                {stat.label}
              </h3>
              
              <p className="font-lato text-sm text-white/80 leading-relaxed">
                {stat.description}
              </p>
            </div>
          ))}
        </div>

        {/* Market insights */}
        <div className="mt-20 grid lg:grid-cols-2 gap-12 animate-fade-in">
          <div>
            <h3 className="font-playfair text-3xl font-bold mb-6">Market Drivers</h3>
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="w-3 h-3 bg-gold rounded-full mt-2 mr-4 flex-shrink-0"></div>
                <div>
                  <h4 className="font-lato font-semibold mb-1">Cultural Renaissance</h4>
                  <p className="font-lato text-sm text-white/80">Growing appreciation for authentic Indian culture and products</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-3 h-3 bg-gold rounded-full mt-2 mr-4 flex-shrink-0"></div>
                <div>
                  <h4 className="font-lato font-semibold mb-1">Premium Demand</h4>
                  <p className="font-lato text-sm text-white/80">Increasing consumer willingness to pay for quality and authenticity</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-3 h-3 bg-gold rounded-full mt-2 mr-4 flex-shrink-0"></div>
                <div>
                  <h4 className="font-lato font-semibold mb-1">Digital Commerce</h4>
                  <p className="font-lato text-sm text-white/80">E-commerce expansion making specialty products more accessible</p>
                </div>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-playfair text-3xl font-bold mb-6">Growth Projections</h3>
            <div className="space-y-6">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="font-lato text-sm">Spices Market</span>
                  <span className="font-lato text-sm text-gold">£2.1B by 2025</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div className="bg-gold h-2 rounded-full w-4/5"></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="font-lato text-sm">Textiles Market</span>
                  <span className="font-lato text-sm text-gold">£1.8B by 2025</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div className="bg-gold h-2 rounded-full w-3/4"></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="font-lato text-sm">Jewellery Market</span>
                  <span className="font-lato text-sm text-gold">£1.2B by 2025</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2">
                  <div className="bg-gold h-2 rounded-full w-3/5"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MarketOpportunity;