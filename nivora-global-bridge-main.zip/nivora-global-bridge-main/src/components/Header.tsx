import { useState } from "react";
import { Menu, X } from "lucide-react";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const menuItems = [
    { label: "Home", href: "/" },
    { label: "About", href: "#about" },
    { label: "Products", href: "#products" },
    { label: "Global Presence", href: "#global-presence" },
    { label: "Team", href: "#team" },
    { label: "Partner With Us", href: "/partner-with-us" },
    { label: "Start Trading", href: "/start-trading" },
    { label: "Contact Us", href: "/contact-us" },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 bg-gradient-to-b from-black/30 via-black/20 to-transparent backdrop-blur-md border-b border-white/20 z-50 shadow-elegant">
      <div className="container mx-auto px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="font-roboto text-3xl font-bold text-primary tracking-tight">
            Nivora Global Ltd
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-10">
            {menuItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="font-inter text-sm font-medium text-white hover:text-gold transition-all duration-300 hover:scale-105 relative group"
              >
                {item.label}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gold transition-all duration-300 group-hover:w-full"></span>
              </a>
            ))}
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-3 text-white hover:text-gold transition-colors duration-200"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden py-6 border-t border-white/20">
            {menuItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={() => setIsMenuOpen(false)}
                className="block py-3 font-inter text-base font-medium text-white hover:text-gold transition-colors duration-200"
              >
                {item.label}
              </a>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;