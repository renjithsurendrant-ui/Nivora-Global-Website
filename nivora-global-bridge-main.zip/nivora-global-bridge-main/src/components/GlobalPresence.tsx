import premiumSpices from "@/assets/premium-spices.jpg";
import luxuryTextiles from "@/assets/luxury-textiles.jpg";
import heritageJewellery from "@/assets/heritage-jewellery.jpg";
import keralaTradeBackground from "@/assets/kerala-trade-background.jpg";

const GlobalPresence = () => {
  const offices = [
    {
      country: "United Kingdom",
      city: "London (HQ)",
      address: "10 Royal Crescent, Ilford, London, IG2 7NH",
      phone: "+44 7532624042",
      icon: "🇬🇧",
      role: "Headquarters & European Operations"
    },
    {
      country: "India",
      city: "Kerala Operations",
      address: "Thareparambil, Thalayazham P O, Vaikom, Kerala, India",
      phone: "+91 9446205777",
      icon: "🇮🇳",
      role: "Sourcing & Production Hub"
    }
  ];

  const tradeRoutes = [
    { from: "Kerala, India", to: "London, UK", product: "Premium Spices", image: premiumSpices, icon: "🌶️" },
    { from: "Munnar & Wayanad, Kerala", to: "London, UK", product: "Premium Tea", image: premiumSpices, icon: "🍃" },
    { from: "Munnar, Kerala", to: "Europe", product: "Lemongrass Oil", image: premiumSpices, icon: "🌿" }
  ];

  return (
    <section id="global-presence" className="py-32 bg-background">
      <div className="container mx-auto px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="font-roboto text-5xl md:text-7xl font-bold text-primary mb-6 tracking-tight">
            Global Presence
          </h2>
          <div className="w-32 h-1 bg-gold mx-auto mb-6"></div>
          <p className="font-inter text-xl text-secondary max-w-3xl mx-auto font-light">
            Strategically positioned across continents to serve global markets with excellence
          </p>
        </div>

        {/* Office Locations */}
        <div className="relative mb-20">
          <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto">
            {offices.map((office, index) => (
              <div key={index} className="text-center p-8 hover:bg-background/50 rounded-3xl transition-all duration-300">
                <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-gold to-gold/80 flex items-center justify-center text-4xl shadow-lg hover:scale-110 hover:shadow-xl transition-all duration-300">
                  {office.icon}
                </div>
                <h3 className="font-roboto text-3xl font-bold text-gold mb-3">
                  {office.city}
                </h3>
                <p className="font-inter text-primary font-semibold mb-4 text-lg">
                  {office.role}
                </p>
                <p className="font-inter text-secondary mb-4 leading-relaxed">
                  {office.address}
                </p>
                <p className="font-inter text-gold font-medium text-lg">
                  {office.phone}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Trade Routes with Background */}
      </div>
      <div 
        className="relative py-32 w-screen -ml-[50vw] left-1/2"
        style={{
          backgroundImage: `url(${keralaTradeBackground})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed'
        }}
      >
        {/* Overlay */}
        <div className="absolute inset-0 bg-black/70"></div>
          
          {/* Content */}
          <div className="relative z-10 max-w-6xl mx-auto px-6 lg:px-8">
            <h3 className="font-roboto text-4xl font-bold text-center text-white mb-12">
              Kerala to World Trade Routes
            </h3>
            <div className="grid md:grid-cols-3 gap-8">
              {tradeRoutes.map((route, index) => (
                <div key={index} className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 text-center border border-white/20 hover:bg-white/20 transition-all duration-300 group">
                  <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gold/20 flex items-center justify-center text-4xl border-4 border-gold hover:scale-110 transition-all duration-300">
                    {route.icon}
                  </div>
                  <h4 className="font-roboto text-xl font-bold text-gold mb-3">
                    {route.product}
                  </h4>
                  <div className="space-y-2">
                    <p className="font-inter text-white/90">
                      <span className="font-medium">From:</span> {route.from}
                    </p>
                    <div className="text-2xl text-gold animate-bounce">↓</div>
                    <p className="font-inter text-white/90">
                      <span className="font-medium">To:</span> {route.to}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
    </section>
  );
};

export default GlobalPresence;