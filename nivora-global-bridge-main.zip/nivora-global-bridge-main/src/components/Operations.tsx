import { ArrowRight, MapPin, Package, Truck, CheckCircle } from "lucide-react";

const Operations = () => {
  const supplyChain = [
    {
      icon: MapPin,
      title: "India Sourcing Hubs",
      location: "Mumbai, Delhi, Chennai, Kolkata",
      description: "Strategic partnerships with certified suppliers across major Indian commercial centers",
      status: "active"
    },
    {
      icon: Package,
      title: "Quality Control",
      location: "Regional Centers",
      description: "Rigorous testing and certification at multiple quality checkpoints",
      status: "active"
    },
    {
      icon: Truck,
      title: "London HQ",
      location: "United Kingdom",
      description: "Central coordination and UK market distribution hub",
      status: "active"
    },
    {
      icon: CheckCircle,
      title: "Global Distribution",
      location: "Worldwide Network",
      description: "Last-mile delivery to customers across UK and international markets",
      status: "active"
    }
  ];

  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-primary mb-6">
            Supply Chain Excellence
          </h2>
          <div className="w-20 h-1 bg-gold mx-auto mb-6"></div>
          <p className="font-lato text-lg text-secondary max-w-3xl mx-auto">
            Our streamlined operations ensure premium quality from source to destination, 
            with full traceability and compliance at every step
          </p>
        </div>

        {/* Supply chain flow */}
        <div className="relative">
          {/* Desktop flow */}
          <div className="hidden lg:flex items-center justify-between mb-16">
            {supplyChain.map((step, index) => (
              <div key={index} className="flex items-center animate-slide-up" style={{animationDelay: `${index * 200}ms`}}>
                <div className="text-center">
                  <div className="w-20 h-20 bg-white rounded-full shadow-elegant flex items-center justify-center mb-4 mx-auto">
                    <step.icon className="h-10 w-10 text-gold" />
                  </div>
                  <h3 className="font-playfair text-xl font-semibold text-primary mb-2">{step.title}</h3>
                  <p className="font-lato text-sm text-gold font-medium mb-1">{step.location}</p>
                  <p className="font-lato text-xs text-secondary max-w-48 mx-auto">{step.description}</p>
                </div>
                
                {index < supplyChain.length - 1 && (
                  <ArrowRight className="h-6 w-6 text-gold mx-8 flex-shrink-0" />
                )}
              </div>
            ))}
          </div>

          {/* Mobile flow */}
          <div className="lg:hidden space-y-8">
            {supplyChain.map((step, index) => (
              <div key={index} className="animate-slide-up" style={{animationDelay: `${index * 200}ms`}}>
                <div className="bg-white p-6 rounded-lg shadow-elegant">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center mr-4">
                      <step.icon className="h-6 w-6 text-gold" />
                    </div>
                    <div>
                      <h3 className="font-playfair text-lg font-semibold text-primary">{step.title}</h3>
                      <p className="font-lato text-sm text-gold font-medium">{step.location}</p>
                    </div>
                  </div>
                  <p className="font-lato text-sm text-secondary">{step.description}</p>
                </div>
                
                {index < supplyChain.length - 1 && (
                  <div className="flex justify-center">
                    <ArrowRight className="h-6 w-6 text-gold transform rotate-90" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Key capabilities */}
        <div className="grid md:grid-cols-3 gap-8 mt-16">
          <div className="text-center p-6 bg-white rounded-lg shadow-elegant animate-fade-in">
            <div className="text-4xl mb-4">🚢</div>
            <h3 className="font-playfair text-xl font-semibold text-primary mb-3">Logistics Excellence</h3>
            <p className="font-lato text-secondary text-sm">
              Strategic partnerships with leading shipping lines and freight forwarders ensure timely, 
              cost-effective delivery worldwide
            </p>
          </div>

          <div className="text-center p-6 bg-white rounded-lg shadow-elegant animate-fade-in delay-200">
            <div className="text-4xl mb-4">📋</div>
            <h3 className="font-playfair text-xl font-semibold text-primary mb-3">Compliance Management</h3>
            <p className="font-lato text-secondary text-sm">
              Full regulatory compliance including customs documentation, 
              health certificates, and origin authentication
            </p>
          </div>

          <div className="text-center p-6 bg-white rounded-lg shadow-elegant animate-fade-in delay-400">
            <div className="text-4xl mb-4">📱</div>
            <h3 className="font-playfair text-xl font-semibold text-primary mb-3">Digital Tracking</h3>
            <p className="font-lato text-secondary text-sm">
              Real-time shipment tracking and automated updates keep all 
              stakeholders informed throughout the supply chain
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Operations;