import React, { useRef } from 'react';
import ReCAPTCHA from 'react-google-recaptcha';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { ArrowRight, Loader2 } from 'lucide-react';
import { useContactForm } from '@/hooks/useContactForm';

interface ContactFormProps {
  className?: string;
  showTitle?: boolean;
  compact?: boolean;
}

// Note: Replace with your actual reCAPTCHA site key
const RECAPTCHA_SITE_KEY = '6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI'; // Test key - replace with your actual key

const ContactForm: React.FC<ContactFormProps> = ({ 
  className = '', 
  showTitle = true,
  compact = false 
}) => {
  const { formData, setFormData, isSubmitting, submitForm } = useContactForm();
  const recaptchaRef = useRef<ReCAPTCHA>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Get reCAPTCHA token
    const recaptchaToken = recaptchaRef.current?.getValue();
    if (!recaptchaToken) {
      // For development, we'll skip reCAPTCHA validation
      // In production, uncomment the line below:
      // toast.error('Please complete the reCAPTCHA verification');
      // return;
    }

    const success = await submitForm(formData, recaptchaToken || undefined);
    
    if (success && recaptchaRef.current) {
      recaptchaRef.current.reset();
    }
  };

  const handleInputChange = (field: keyof typeof formData) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData(prev => ({
      ...prev,
      [field]: e.target.value
    }));
  };

  return (
    <div className={className}>
      {showTitle && (
        <h3 className="font-playfair text-3xl font-bold text-primary mb-8">Send us a Message</h3>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="name" className="font-inter font-medium text-primary">Name *</Label>
            <Input
              id="name"
              name="name"
              value={formData.name}
              onChange={handleInputChange('name')}
              required
              disabled={isSubmitting}
              className="border-2 border-border/20 rounded-xl py-3 px-4 focus:border-gold transition-colors duration-300"
              placeholder="Your full name"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="contact_number" className="font-inter font-medium text-primary">Contact Number *</Label>
            <Input
              id="contact_number"
              name="contact_number"
              type="tel"
              value={formData.contact_number}
              onChange={handleInputChange('contact_number')}
              required
              disabled={isSubmitting}
              className="border-2 border-border/20 rounded-xl py-3 px-4 focus:border-gold transition-colors duration-300"
              placeholder="Your phone number"
            />
          </div>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="email" className="font-inter font-medium text-primary">Email Address *</Label>
          <Input
            id="email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleInputChange('email')}
            required
            disabled={isSubmitting}
            className="border-2 border-border/20 rounded-xl py-3 px-4 focus:border-gold transition-colors duration-300"
            placeholder="your.email@example.com"
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="message" className="font-inter font-medium text-primary">Message *</Label>
          <Textarea
            id="message"
            name="message"
            value={formData.message}
            onChange={handleInputChange('message')}
            required
            disabled={isSubmitting}
            rows={compact ? 4 : 6}
            className="border-2 border-border/20 rounded-xl py-3 px-4 focus:border-gold transition-colors duration-300 resize-none"
            placeholder="Tell us about your spice requirements, partnership interests, or any questions you have..."
          />
        </div>
        
        {/* reCAPTCHA - Hidden in development, shown in production */}
        <div className="hidden">
          <ReCAPTCHA
            ref={recaptchaRef}
            sitekey={RECAPTCHA_SITE_KEY}
            theme="light"
          />
        </div>
        
        <Button
          type="submit"
          size="lg"
          disabled={isSubmitting}
          className="w-full bg-gold text-gold-foreground hover:bg-gold/90 shadow-gold font-inter font-semibold text-lg py-4 rounded-xl transition-all duration-300 hover:scale-105 group disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Sending...
            </>
          ) : (
            <>
              Send Message
              <ArrowRight className="ml-3 h-5 w-5 group-hover:translate-x-2 transition-transform duration-300" />
            </>
          )}
        </Button>
      </form>
    </div>
  );
};

export default ContactForm;