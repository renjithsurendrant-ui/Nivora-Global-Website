import { Button } from "@/components/ui/button";
import { Mail, Globe, MapPin, Phone, ArrowRight } from "lucide-react";

const ContactCTA = () => {
  return (
    <section className="py-20 bg-gradient-primary text-white relative overflow-hidden">
      {/* Background patterns */}
      <div className="absolute inset-0 opacity-10">
        <div 
          className="w-full h-full"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23D4AF37' fill-opacity='0.1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        ></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="font-playfair text-4xl md:text-6xl font-bold mb-6">
            Ready to Start Trading?
          </h2>
          <div className="w-20 h-1 bg-gold mx-auto mb-6"></div>
          <p className="font-lato text-xl text-white/90 max-w-3xl mx-auto mb-8">
            Join the growing network of successful partners who trust Nivora Global 
            for premium Indian products in the UK market
          </p>
          
          <Button 
            size="lg" 
            className="bg-gold text-gold-foreground hover:bg-gold/90 shadow-gold font-lato font-semibold text-lg px-12 py-6 group mb-16"
          >
            Start Trading with Us
            <ArrowRight className="ml-3 h-6 w-6 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 animate-slide-up">
          {/* Email */}
          <div className="text-center p-6 bg-white/10 rounded-lg backdrop-blur-sm">
            <div className="w-16 h-16 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mail className="h-8 w-8 text-gold" />
            </div>
            <h3 className="font-playfair text-lg font-semibold mb-2">Email</h3>
            <p className="font-lato text-white/80 text-sm mb-3">Get in touch directly</p>
            <a 
              href="mailto:info@nivoraglobal.com" 
              className="font-lato text-gold hover:text-white transition-colors text-sm"
            >
              info@nivoraglobal.com
            </a>
          </div>

          {/* Website */}
          <div className="text-center p-6 bg-white/10 rounded-lg backdrop-blur-sm">
            <div className="w-16 h-16 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Globe className="h-8 w-8 text-gold" />
            </div>
            <h3 className="font-playfair text-lg font-semibold mb-2">Website</h3>
            <p className="font-lato text-white/80 text-sm mb-3">Visit our online presence</p>
            <a 
              href="https://nivoraglobal.com" 
              className="font-lato text-gold hover:text-white transition-colors text-sm"
              target="_blank"
              rel="noopener noreferrer"
            >
              nivoraglobal.com
            </a>
          </div>

          {/* Phone */}
          <div className="text-center p-6 bg-white/10 rounded-lg backdrop-blur-sm">
            <div className="w-16 h-16 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Phone className="h-8 w-8 text-gold" />
            </div>
            <h3 className="font-playfair text-lg font-semibold mb-2">Phone</h3>
            <p className="font-lato text-white/80 text-sm mb-3">Speak with our team</p>
            <a 
              href="tel:+44-20-xxxx-xxxx" 
              className="font-lato text-gold hover:text-white transition-colors text-sm"
            >
              +44 20 XXXX XXXX
            </a>
          </div>

          {/* Address */}
          <div className="text-center p-6 bg-white/10 rounded-lg backdrop-blur-sm">
            <div className="w-16 h-16 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <MapPin className="h-8 w-8 text-gold" />
            </div>
            <h3 className="font-playfair text-lg font-semibold mb-2">London HQ</h3>
            <p className="font-lato text-white/80 text-sm mb-3">Visit our office</p>
            <p className="font-lato text-gold text-sm">
              Central London<br />
              United Kingdom
            </p>
          </div>
        </div>

        {/* Additional CTA section */}
        <div className="mt-16 text-center animate-fade-in">
          <div className="bg-white/5 rounded-2xl p-8 backdrop-blur-sm border border-white/10">
            <h3 className="font-playfair text-2xl font-bold mb-4">Why Choose Nivora Global?</h3>
            <div className="grid md:grid-cols-3 gap-6 text-sm">
              <div>
                <div className="text-gold font-semibold mb-2">✓ Authentic Products</div>
                <p className="text-white/80">Direct sourcing from certified suppliers</p>
              </div>
              <div>
                <div className="text-gold font-semibold mb-2">✓ Quality Assured</div>
                <p className="text-white/80">Rigorous testing and certification</p>
              </div>
              <div>
                <div className="text-gold font-semibold mb-2">✓ Reliable Partners</div>
                <p className="text-white/80">Proven track record of excellence</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactCTA;