import ContactForm from "@/components/ContactForm";
import { Toaster } from "@/components/ui/sonner";

const Contact = () => {
  return (
    <section id="contact" className="py-32 bg-primary relative overflow-hidden">
      {/* Background pattern */}
      <div 
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23FFB300'%3E%3Cpath d='M10 10h40v2H10zM15 20h30v1H15zM5 30h50v2H5zM20 40h20v1H20z'/%3E%3C/g%3E%3C/svg%3E")`,
        }}
      ></div>
      
      <div className="container mx-auto px-6 lg:px-8 relative">
        <div className="text-center mb-20">
          <h2 className="font-roboto text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight">
            Connect With Us
          </h2>
          <div className="w-32 h-1 bg-gold mx-auto mb-6"></div>
          <p className="font-inter text-xl text-white/80 max-w-3xl mx-auto font-light">
            Ready to source premium Kerala spices? Connect with our global offices for authentic quality.
          </p>
        </div>

        <div className="max-w-4xl mx-auto mb-16">
          {/* Contact Form */}
          <div className="bg-white rounded-3xl shadow-2xl border border-border/20 overflow-hidden">
            <div className="grid md:grid-cols-2">
              {/* Contact Info */}
              <div className="bg-gradient-to-br from-primary to-primary/90 p-12 text-white">
                <h3 className="font-playfair text-3xl font-bold mb-8">Get in Touch</h3>
                <p className="font-inter text-white/80 mb-8 leading-relaxed">
                  Connect with our global offices for premium Kerala spices, authentic quality, and trusted partnerships worldwide.
                </p>
                
                {/* Office Cards */}
                <div className="space-y-6">
                  <div className="bg-white/10 rounded-xl p-6 backdrop-blur-sm">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-gold rounded-lg flex items-center justify-center text-primary text-lg">
                        🇬🇧
                      </div>
                      <div>
                        <h4 className="font-roboto font-semibold">London Office</h4>
                        <p className="font-inter text-white/70 text-sm">+44 7532624042</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white/10 rounded-xl p-6 backdrop-blur-sm">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-gold rounded-lg flex items-center justify-center text-primary text-lg">
                        🇮🇳
                      </div>
                      <div>
                        <h4 className="font-roboto font-semibold">India Office</h4>
                        <p className="font-inter text-white/70 text-sm">+91 9446205777</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Contact Form */}
              <div className="p-12">
                <ContactForm compact={true} />
              </div>
            </div>
          </div>
        </div>
      </div>
      <Toaster />
    </section>
  );
};

export default Contact;