import { CheckCircle, XCircle } from "lucide-react";

const ProblemSolution = () => {
  const problems = [
    "Limited access to authentic Indian products in UK",
    "Quality concerns and lack of trust",
    "Complex import regulations and documentation",
    "Cultural disconnect in product presentation"
  ];

  const solutions = [
    "Direct sourcing from trusted Indian manufacturers",
    "Rigorous quality control and certification",
    "Full compliance and documentation support", 
    "Culturally sensitive marketing and presentation"
  ];

  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-primary mb-6">
            Solving Global Trade Challenges
          </h2>
          <div className="w-20 h-1 bg-gold mx-auto mb-6"></div>
          <p className="font-lato text-lg text-secondary max-w-3xl mx-auto">
            We identify market gaps and provide innovative solutions for seamless international trade
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16">
          {/* Problems */}
          <div className="animate-slide-up">
            <div className="bg-white p-8 rounded-lg shadow-elegant">
              <div className="flex items-center mb-6">
                <XCircle className="h-8 w-8 text-destructive mr-3" />
                <h3 className="font-playfair text-2xl font-semibold text-primary">Market Challenges</h3>
              </div>
              
              <ul className="space-y-4">
                {problems.map((problem, index) => (
                  <li key={index} className="flex items-start">
                    <div className="w-2 h-2 bg-destructive rounded-full mt-3 mr-4 flex-shrink-0"></div>
                    <span className="font-lato text-secondary">{problem}</span>
                  </li>
                ))}
              </ul>
              
              <div className="mt-8 p-4 bg-destructive/5 rounded-lg border-l-4 border-destructive">
                <p className="font-lato text-sm text-secondary">
                  These challenges create barriers to authentic cultural exchange and limit access to premium Indian products
                </p>
              </div>
            </div>
          </div>

          {/* Solutions */}
          <div className="animate-slide-up delay-300">
            <div className="bg-white p-8 rounded-lg shadow-elegant">
              <div className="flex items-center mb-6">
                <CheckCircle className="h-8 w-8 text-gold mr-3" />
                <h3 className="font-playfair text-2xl font-semibold text-primary">Nivora Solutions</h3>
              </div>
              
              <ul className="space-y-4">
                {solutions.map((solution, index) => (
                  <li key={index} className="flex items-start">
                    <div className="w-2 h-2 bg-gold rounded-full mt-3 mr-4 flex-shrink-0"></div>
                    <span className="font-lato text-secondary">{solution}</span>
                  </li>
                ))}
              </ul>
              
              <div className="mt-8 p-4 bg-gold/5 rounded-lg border-l-4 border-gold">
                <p className="font-lato text-sm text-secondary">
                  Our comprehensive approach ensures authentic products reach the right markets with proper cultural context
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Impact metrics */}
        <div className="grid md:grid-cols-3 gap-8 mt-16 animate-fade-in">
          <div className="text-center">
            <div className="text-4xl font-playfair font-bold text-gold mb-2">95%</div>
            <div className="font-lato text-secondary">Quality Assurance</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-playfair font-bold text-gold mb-2">100%</div>
            <div className="font-lato text-secondary">Compliance Rate</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-playfair font-bold text-gold mb-2">500+</div>
            <div className="font-lato text-secondary">Trusted Partners</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProblemSolution;