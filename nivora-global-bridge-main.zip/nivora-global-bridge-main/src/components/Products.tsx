import premiumSpicesIcon from "@/assets/premium-spices-icon.jpg";
import keralaSpicer from "@/assets/kerala-spice-plantation.jpg";

const Products = () => {
  const products = [
    {
      name: "Black Pepper",
      description: "Premium Kerala black pepper known for its pungent aroma and superior quality",
      icon: "🌶️",
    },
    {
      name: "Green Cardamom", 
      description: "Aromatic cardamom pods from the hills of Munnar and Idukki",
      icon: "💚",
    },
    {
      name: "Turmeric",
      description: "Golden turmeric powder with high curcumin content from Kerala farms", 
      icon: "🟡",
    },
    {
      name: "Cinnamon",
      description: "True Ceylon cinnamon quills with delicate flavor and aroma", 
      icon: "🟤",
    },
    {
      name: "Cloves",
      description: "Hand-picked clove buds with intense aromatic properties", 
      icon: "🌸",
    },
    {
      name: "Nutmeg",
      description: "Premium nutmeg with rich flavor from Kerala spice gardens", 
      icon: "🥜",
    }
  ];

  return (
    <section id="products" className="py-32 bg-background">
      <div className="container mx-auto px-6 lg:px-8">
        <div className="text-center mb-20">
          <div className="flex items-center justify-center mb-6">
            <div className="w-8 h-8 mr-4">
              <span className="text-4xl">🌾</span>
            </div>
            <h2 className="font-playfair text-4xl md:text-5xl font-bold text-primary tracking-tight">
              Premium Spices
            </h2>
            <div className="w-8 h-8 ml-4">
              <span className="text-4xl">🌾</span>
            </div>
          </div>
          <h3 className="font-playfair text-3xl md:text-4xl font-medium text-secondary mb-8">
            We Provide Organic Spice Services to Get Better Health
          </h3>
        </div>

        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
          {/* Left Column - Products */}
          <div className="flex-1 space-y-8">
            {products.slice(0, 3).map((product, index) => (
              <div key={index} className="flex items-center space-x-4 p-4 rounded-2xl hover:bg-white/50 transition-all duration-300">
                <div className="w-16 h-16 bg-gold/10 rounded-2xl flex items-center justify-center">
                  <span className="text-3xl">{product.icon}</span>
                </div>
                <div>
                  <h4 className="font-playfair text-xl font-semibold text-primary mb-2">
                    {product.name}
                  </h4>
                  <p className="font-inter text-secondary/80 text-sm leading-relaxed">
                    {product.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Center Image */}
          <div className="flex-shrink-0">
            <div className="relative">
              <div 
                className="w-80 h-80 rounded-full overflow-hidden"
                style={{
                  backgroundImage: `url(${keralaSpicer})`,
                  backgroundSize: 'cover',
                  backgroundPosition: 'center',
                  backgroundRepeat: 'no-repeat'
                }}
                role="img"
                aria-label="Kerala spice plantation worker"
              />
              <div className="absolute inset-0 rounded-full bg-gradient-to-t from-black/20 to-transparent"></div>
            </div>
          </div>

          {/* Right Column - Products */}
          <div className="flex-1 space-y-8">
            {products.slice(3, 6).map((product, index) => (
              <div key={index + 3} className="flex items-center space-x-4 p-4 rounded-2xl hover:bg-white/50 transition-all duration-300">
                <div className="w-16 h-16 bg-gold/10 rounded-2xl flex items-center justify-center">
                  <span className="text-3xl">{product.icon}</span>
                </div>
                <div>
                  <h4 className="font-playfair text-xl font-semibold text-primary mb-2">
                    {product.name}
                  </h4>
                  <p className="font-inter text-secondary/80 text-sm leading-relaxed">
                    {product.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Products;