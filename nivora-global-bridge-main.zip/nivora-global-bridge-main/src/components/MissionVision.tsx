const MissionVision = () => {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Mission */}
          <div className="animate-slide-up">
            <div className="mb-8">
              <h2 className="font-playfair text-4xl md:text-5xl font-bold text-primary mb-6">
                Our Mission
              </h2>
              <div className="w-20 h-1 bg-gold mb-6"></div>
              <p className="font-lato text-lg text-secondary leading-relaxed mb-6">
                To bridge the cultural and commercial gap between India and the UK by 
                delivering authentic, premium-quality products that celebrate Indian 
                heritage while meeting modern British standards.
              </p>
              <p className="font-lato text-base text-muted-foreground leading-relaxed">
                We are committed to fostering trust, ensuring quality, and creating 
                lasting partnerships that benefit producers in India and consumers in the UK.
              </p>
            </div>
          </div>
          
          {/* Vision */}
          <div className="animate-slide-up delay-300">
            <div className="mb-8">
              <h2 className="font-playfair text-4xl md:text-5xl font-bold text-primary mb-6">
                Our Vision
              </h2>
              <div className="w-20 h-1 bg-gold mb-6"></div>
              <p className="font-lato text-lg text-secondary leading-relaxed mb-6">
                To become the leading export-import company connecting India and the UK, 
                renowned for excellence, authenticity, and cultural sensitivity in 
                international trade.
              </p>
              <p className="font-lato text-base text-muted-foreground leading-relaxed">
                We envision a future where premium Indian products are accessible 
                worldwide, supporting local artisans and contributing to global 
                cultural exchange.
              </p>
            </div>
          </div>
        </div>
        
        {/* Trust indicators */}
        <div className="grid md:grid-cols-3 gap-8 mt-16 animate-fade-in">
          <div className="text-center p-6">
            <div className="w-16 h-16 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">🌍</span>
            </div>
            <h3 className="font-playfair text-xl font-semibold text-primary mb-2">Global Reach</h3>
            <p className="font-lato text-muted-foreground">Connecting markets across continents</p>
          </div>
          
          <div className="text-center p-6">
            <div className="w-16 h-16 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">⭐</span>
            </div>
            <h3 className="font-playfair text-xl font-semibold text-primary mb-2">Premium Quality</h3>
            <p className="font-lato text-muted-foreground">Curated selection of finest products</p>
          </div>
          
          <div className="text-center p-6">
            <div className="w-16 h-16 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">🤝</span>
            </div>
            <h3 className="font-playfair text-xl font-semibold text-primary mb-2">Trusted Partners</h3>
            <p className="font-lato text-muted-foreground">Building lasting relationships</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MissionVision;