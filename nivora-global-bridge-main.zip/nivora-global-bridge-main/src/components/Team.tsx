import renjithImage from "@/assets/team/renjith-surendran.jpg";
import ajithImage from "@/assets/team/ajith-surendran.jpg";
import robinImage from "@/assets/team/robin-erickattu.jpg";
import rebinImage from "@/assets/team/rebin-erickattu.jpg";

const Team = () => {
  const teamMembers = [
    {
      name: "Renjith Surendran",
      role: "Founder & CEO",
      bio: "Visionary leader bridging Kerala's rich heritage with global markets, driving strategic growth and cultural connections across continents.",
      image: renjithImage,
      expertise: ["International Trade", "Strategic Leadership", "Cultural Bridge-building"]
    },
    {
      name: "Ajith Surendran", 
      role: "Chief Financial Officer",
      bio: "Financial strategist ensuring sustainable growth and operational excellence across all international trade operations.",
      image: ajithImage,
      expertise: ["Financial Management", "Investment Strategy", "Risk Assessment"]
    },
    {
      name: "Robin Erickattu",
      role: "Director - Marketing",
      bio: "Creative marketing leader building global brand presence and connecting premium Indian products with international markets.",
      image: robinImage,
      expertise: ["Global Marketing", "Brand Development", "Digital Strategy"]
    },
    {
      name: "Rebin Erickattu",
      role: "Director - Finance & Auditing", 
      bio: "Ensuring financial transparency and compliance across all operations while maintaining the highest standards of corporate governance.",
      image: rebinImage,
      expertise: ["Financial Auditing", "Compliance", "Corporate Governance"]
    }
  ];

  return (
    <section id="team" className="py-32 bg-background">
      <div className="container mx-auto px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="font-roboto text-5xl md:text-7xl font-bold text-primary mb-6 tracking-tight">
            Leadership Team
          </h2>
          <div className="w-32 h-1 bg-gold mx-auto mb-6"></div>
          <p className="font-inter text-xl text-secondary max-w-3xl mx-auto font-light">
            Meet the experienced professionals driving Nivora Global Ltd's mission forward
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {teamMembers.map((member, index) => (
            <div key={index} className="group bg-white shadow-elegant rounded-3xl overflow-hidden hover:shadow-lg transition-all duration-300 border border-border">
              {/* Photo at top */}
              <div className="aspect-[4/3] overflow-hidden">
                <img 
                  src={member.image} 
                  alt={member.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              
              {/* Content */}
              <div className="p-8">
                <h3 className="font-roboto text-2xl font-bold text-primary mb-2 group-hover:text-gold transition-colors duration-300">
                  {member.name}
                </h3>
                <p className="font-inter text-gold font-semibold mb-4 text-lg">
                  {member.role}
                </p>
                <p className="font-inter text-secondary mb-6 leading-relaxed text-base font-medium">
                  {member.bio}
                </p>
                <div className="space-y-3">
                  <p className="font-inter font-semibold text-primary text-sm">Expertise:</p>
                  <div className="flex flex-wrap gap-2">
                    {member.expertise.map((skill, skillIndex) => (
                      <span key={skillIndex} className="px-3 py-1 bg-gold/10 text-gold text-xs rounded-md font-inter font-medium border border-gold/20">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Team;