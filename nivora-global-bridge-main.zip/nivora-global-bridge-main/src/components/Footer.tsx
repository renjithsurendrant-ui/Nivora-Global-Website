const Footer = () => {
  return (
    <footer className="bg-primary">
      <div className="container mx-auto px-6 lg:px-8 py-16">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-gold rounded-lg flex items-center justify-center">
                <span className="text-primary font-bold text-lg">N</span>
              </div>
              <span className="font-playfair text-2xl font-bold text-white">Nivora Global</span>
            </div>
            <p className="font-inter text-white/70 mb-6 leading-relaxed text-sm">
              We create premium spice exporters, individual traders, diet and nutrition consultants, as well as other specialists who need quality products. Check our latest work in profile.....
            </p>
            <div className="mb-6">
              <h4 className="font-playfair font-semibold text-white mb-4">Follow us</h4>
              <div className="flex space-x-4">
                <a href="#" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-gold hover:text-primary transition-colors duration-200">
                  <span className="text-lg">📘</span>
                </a>
                <a href="#" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-gold hover:text-primary transition-colors duration-200">
                  <span className="text-lg">💼</span>
                </a>
                <a href="#" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-gold hover:text-primary transition-colors duration-200">
                  <span className="text-lg">🌐</span>
                </a>
                <a href="#" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-gold hover:text-primary transition-colors duration-200">
                  <span className="text-lg">🐦</span>
                </a>
                <a href="#" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-gold hover:text-primary transition-colors duration-200">
                  <span className="text-lg">📺</span>
                </a>
              </div>
            </div>
          </div>

          {/* About Navigation */}
          <div>
            <h4 className="font-playfair font-semibold text-white mb-6">About</h4>
            <ul className="space-y-3">
              <li>
                <a href="/" className="font-inter text-white/70 hover:text-gold transition-colors duration-200 text-sm">
                  Home
                </a>
              </li>
              <li>
                <a href="/partner-with-us" className="font-inter text-white/70 hover:text-gold transition-colors duration-200 text-sm">
                  Partner With Us
                </a>
              </li>
              <li>
                <a href="/start-trading" className="font-inter text-white/70 hover:text-gold transition-colors duration-200 text-sm">
                  Start Trading
                </a>
              </li>
              <li>
                <a href="/contact-us" className="font-inter text-white/70 hover:text-gold transition-colors duration-200 text-sm">
                  Contact Us
                </a>
              </li>
              <li>
                <a href="#about" className="font-inter text-white/70 hover:text-gold transition-colors duration-200 text-sm">
                  About Us
                </a>
              </li>
              <li>
                <a href="#team" className="font-inter text-white/70 hover:text-gold transition-colors duration-200 text-sm">
                  Our Team
                </a>
              </li>
            </ul>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="font-playfair font-semibold text-white mb-6">Navigation</h4>
            <ul className="space-y-3">
              <li>
                <a href="#" className="font-inter text-white/70 hover:text-gold transition-colors duration-200 text-sm">
                  Our Partners
                </a>
              </li>
              <li>
                <a href="#" className="font-inter text-white/70 hover:text-gold transition-colors duration-200 text-sm">
                  Our Team
                </a>
              </li>
              <li>
                <a href="#" className="font-inter text-white/70 hover:text-gold transition-colors duration-200 text-sm">
                  Accounting
                </a>
              </li>
              <li>
                <a href="#" className="font-inter text-white/70 hover:text-gold transition-colors duration-200 text-sm">
                  Finance CA
                </a>
              </li>
              <li>
                <a href="#" className="font-inter text-white/70 hover:text-gold transition-colors duration-200 text-sm">
                  FAQ
                </a>
              </li>
              <li>
                <a href="#" className="font-inter text-white/70 hover:text-gold transition-colors duration-200 text-sm">
                  Privacy Policy
                </a>
              </li>
            </ul>
          </div>

          {/* Subscribe */}
          <div>
            <h4 className="font-playfair font-semibold text-white mb-6">Subscribes</h4>
            <p className="font-inter text-white/70 text-sm mb-6">
              Sign up for our mailing list to get latest updates and offers
            </p>
            <div className="flex">
              <input
                type="email"
                placeholder="Email"
                className="flex-1 px-4 py-3 rounded-l-lg bg-white/10 border border-white/20 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent"
              />
              <button className="px-6 py-3 bg-gold text-primary rounded-r-lg hover:bg-gold/90 transition-colors duration-200 font-medium">
                ✉️
              </button>
            </div>
            <div className="mt-6">
              <p className="font-inter text-white/70 text-sm mb-2">
                <span className="font-semibold">Working Hours:</span> Monday-Saturday
              </p>
              <p className="font-inter text-white/70 text-sm">
                <span className="font-semibold">Close:</span> Sunday
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-white/10 mt-12 pt-8 text-center">
          <p className="font-inter text-white/70 text-sm">
            Copyright © 2018 <span className="text-gold">Nivora Global</span> Template by <span className="text-gold">Nivora_Template</span>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;