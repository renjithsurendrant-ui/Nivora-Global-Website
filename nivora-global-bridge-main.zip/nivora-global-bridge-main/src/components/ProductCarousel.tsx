import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

const ProductCarousel = () => {
  const products = [
    {
      title: "Kerala Black Pepper",
      category: "Premium Spices",
      description: "World's finest black pepper from Wayanad hills with intense aroma",
      image: "🌶️",
      bgGradient: "from-red-500/20 to-orange-500/20"
    },
    {
      title: "Munnar Cardamom", 
      category: "Premium Spices",
      description: "Green cardamom pods from high-altitude plantations of Munnar",
      image: "💚",
      bgGradient: "from-green-500/20 to-emerald-500/20"
    },
    {
      title: "Alleppey Turmeric",
      category: "Premium Spices", 
      description: "Golden turmeric with high curcumin content from Kerala farms",
      image: "🟡",
      bgGradient: "from-yellow-500/20 to-amber-500/20"
    }
  ];

  return (
    <section className="py-32 bg-background" id="carousel">
      <div className="container mx-auto px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="font-roboto text-5xl md:text-7xl font-bold text-primary mb-6 tracking-tight">
            Kerala Spice Varieties
          </h2>
          <div className="w-32 h-1 bg-gold mx-auto mb-6"></div>
          <p className="font-inter text-xl text-secondary max-w-2xl mx-auto font-light">
            Discover the authentic flavors of Kerala's finest spice heritage
          </p>
        </div>

        <Carousel className="max-w-6xl mx-auto">
          <CarouselContent>
            {products.map((product, index) => (
              <CarouselItem key={index}>
                <div className={`relative h-[500px] md:h-[600px] rounded-3xl overflow-hidden bg-gradient-to-br ${product.bgGradient} shadow-elegant`}>
                  <div className="absolute inset-0 bg-primary/20 backdrop-blur-[1px]"></div>
                  <div className="relative z-10 flex flex-col items-center justify-center h-full text-center p-12">
                    <div className="text-9xl mb-12 drop-shadow-lg">{product.image}</div>
                    <h3 className="font-roboto text-4xl md:text-6xl font-bold text-primary mb-6 tracking-tight">
                      {product.title}
                    </h3>
                    <p className="font-inter text-xl text-secondary max-w-lg font-light leading-relaxed mb-8">
                      {product.description}
                    </p>
                    <div className="px-8 py-3 bg-gold/30 rounded-full backdrop-blur-sm border border-gold/50">
                      <span className="font-inter font-semibold text-primary text-lg">{product.category}</span>
                    </div>
                  </div>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="left-6 w-14 h-14 bg-gold/20 border-gold/50 hover:bg-gold/30" />
          <CarouselNext className="right-6 w-14 h-14 bg-gold/20 border-gold/50 hover:bg-gold/30" />
        </Carousel>
      </div>
    </section>
  );
};

export default ProductCarousel;