import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ContactForm from "@/components/ContactForm";
import { Toaster } from "@/components/ui/sonner";

const ContactUs = () => {

  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="py-32 bg-gradient-to-br from-primary to-primary/90 relative overflow-hidden">
          <div 
            className="absolute inset-0 opacity-5"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23FFB300'%3E%3Cpath d='M10 10h40v2H10zM15 20h30v1H15zM5 30h50v2H5zM20 40h20v1H20z'/%3E%3C/g%3E%3C/svg%3E")`,
            }}
          ></div>
          
          <div className="container mx-auto px-6 lg:px-8 relative">
            <div className="text-center">
              <h1 className="font-playfair text-6xl md:text-8xl font-bold text-white mb-6 tracking-tight">
                Contact Us
              </h1>
              <div className="w-32 h-1 bg-gold mx-auto mb-6"></div>
              <p className="font-inter text-xl text-white/80 max-w-3xl mx-auto font-light">
                Ready to explore premium Kerala spices? Get in touch with our global team for authentic quality and reliable partnerships.
              </p>
            </div>
          </div>
        </section>

        {/* Contact Form Section */}
        <section className="py-20 bg-background">
          <div className="container mx-auto px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <div className="bg-white rounded-3xl shadow-2xl border border-border/20 overflow-hidden">
                <div className="grid md:grid-cols-2">
                  {/* Contact Info */}
                  <div className="bg-gradient-to-br from-primary to-primary/90 p-12 text-white">
                    <h2 className="font-playfair text-4xl font-bold mb-8">Get in Touch</h2>
                    <p className="font-inter text-white/80 mb-12 leading-relaxed">
                      Connect with our global offices for premium Kerala spices, authentic quality, and trusted partnerships worldwide.
                    </p>
                    
                    <div className="space-y-8">
                      <div className="flex items-start space-x-4">
                        <div className="w-12 h-12 bg-gold rounded-xl flex items-center justify-center text-primary text-xl">
                          📍
                        </div>
                        <div>
                          <h3 className="font-roboto font-semibold mb-2">London Office</h3>
                          <p className="font-inter text-white/80 text-sm leading-relaxed">
                            10 Royal Crescent, Ilford<br />
                            London, IG2 7NH, United Kingdom
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-start space-x-4">
                        <div className="w-12 h-12 bg-gold rounded-xl flex items-center justify-center text-primary text-xl">
                          📞
                        </div>
                        <div>
                          <h3 className="font-roboto font-semibold mb-2">Phone Numbers</h3>
                          <p className="font-inter text-white/80 text-sm">
                            UK: +44 7532624042<br />
                            India: +91 9446205777
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-start space-x-4">
                        <div className="w-12 h-12 bg-gold rounded-xl flex items-center justify-center text-primary text-xl">
                          📧
                        </div>
                        <div>
                          <h3 className="font-roboto font-semibold mb-2">Email & Web</h3>
                          <p className="font-inter text-white/80 text-sm">
                            info@nivoraglobal.com<br />
                            www.nivoraglobal.com
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Contact Form */}
                  <div className="p-12">
                    <ContactForm />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <Toaster />
    </div>
  );
};

export default ContactUs;