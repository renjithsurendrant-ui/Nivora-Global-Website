import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { ArrowRight, Globe, Users, TrendingUp, Shield, Clock, Award } from "lucide-react";

const PartnerWithUs = () => {
  const benefits = [
    {
      icon: Globe,
      title: "Global Network Access",
      description: "Tap into our established network across UK, Europe, and India for seamless international trade operations."
    },
    {
      icon: Users,
      title: "Expert Team Support",
      description: "Work with our experienced professionals who understand both local markets and global trade dynamics."
    },
    {
      icon: TrendingUp,
      title: "Growth Opportunities",
      description: "Access emerging markets and premium product categories with proven track records of success."
    },
    {
      icon: Shield,
      title: "Quality Assurance",
      description: "Our rigorous quality control ensures every product meets international standards and customer expectations."
    },
    {
      icon: Clock,
      title: "Efficient Operations",
      description: "Streamlined processes and logistics management for faster time-to-market and reduced operational costs."
    },
    {
      icon: Award,
      title: "Proven Expertise",
      description: "Leverage our deep knowledge in premium spices, luxury textiles, and heritage jewellery exports."
    }
  ];

  const partnerships = [
    {
      type: "Suppliers & Manufacturers",
      description: "Join our network of trusted suppliers providing premium Indian products to global markets.",
      benefits: ["Quality certification support", "Market access expansion", "Fair pricing agreements"]
    },
    {
      type: "Distributors & Retailers",
      description: "Become an exclusive distributor for authentic Indian products in your region.",
      benefits: ["Exclusive territory rights", "Marketing support", "Training programs"]
    },
    {
      type: "Logistics Partners",
      description: "Collaborate with us to provide efficient shipping and customs clearance services.",
      benefits: ["Volume-based contracts", "Technology integration", "Long-term partnerships"]
    }
  ];

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Hero Section */}
      <section className="py-32 bg-primary text-white">
        <div className="container mx-auto px-6 lg:px-8 text-center">
          <h1 className="font-roboto text-5xl md:text-7xl font-bold mb-6 tracking-tight">
            Partner With <span className="text-gold">Nivora Global</span>
          </h1>
          <div className="w-32 h-1 bg-gold mx-auto mb-6"></div>
          <p className="font-inter text-xl text-white/80 max-w-3xl mx-auto mb-12">
            Join forces with a leading UK-based export company and unlock new opportunities in global trade
          </p>
          <Button 
            size="lg" 
            className="bg-gold text-gold-foreground hover:bg-gold/90 font-semibold px-12 py-6 text-lg rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300"
          >
            <ArrowRight className="mr-2 h-5 w-5" />
            Start Partnership Discussion
          </Button>
        </div>
      </section>

      {/* Partnership Benefits */}
      <section className="py-32 bg-background">
        <div className="container mx-auto px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="font-roboto text-5xl md:text-6xl font-bold text-primary mb-6 tracking-tight">
              Why Partner With Us?
            </h2>
            <div className="w-32 h-1 bg-gold mx-auto mb-6"></div>
            <p className="font-inter text-xl text-secondary max-w-3xl mx-auto">
              Discover the advantages of partnering with Nivora Global for your international trade needs
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {benefits.map((benefit, index) => (
              <div key={index} className="bg-white rounded-2xl p-8 shadow-lg border border-border hover:shadow-xl transition-all duration-300 group">
                <div className="w-16 h-16 bg-gold/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-gold/20 transition-colors duration-300">
                  <benefit.icon className="h-8 w-8 text-gold" />
                </div>
                <h3 className="font-roboto text-xl font-bold text-primary mb-4">
                  {benefit.title}
                </h3>
                <p className="font-inter text-secondary leading-relaxed">
                  {benefit.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Partnership Types */}
      <section className="py-32 bg-primary text-white">
        <div className="container mx-auto px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="font-roboto text-5xl md:text-6xl font-bold mb-6 tracking-tight">
              Partnership Opportunities
            </h2>
            <div className="w-32 h-1 bg-gold mx-auto mb-6"></div>
            <p className="font-inter text-xl text-white/80 max-w-3xl mx-auto">
              Multiple ways to collaborate and grow together in the global marketplace
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {partnerships.map((partnership, index) => (
              <div key={index} className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20 hover:bg-white/20 transition-all duration-300">
                <h3 className="font-roboto text-2xl font-bold text-gold mb-4">
                  {partnership.type}
                </h3>
                <p className="font-inter text-white/90 mb-6 leading-relaxed">
                  {partnership.description}
                </p>
                <div className="space-y-2">
                  {partnership.benefits.map((benefit, benefitIndex) => (
                    <div key={benefitIndex} className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-gold rounded-full"></div>
                      <span className="font-inter text-white/80 text-sm">{benefit}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-32 bg-background">
        <div className="container mx-auto px-6 lg:px-8 text-center">
          <h2 className="font-roboto text-4xl md:text-5xl font-bold text-primary mb-6">
            Ready to Start Your Partnership Journey?
          </h2>
          <p className="font-inter text-xl text-secondary mb-12 max-w-2xl mx-auto">
            Contact our partnership team to discuss how we can work together to achieve mutual success
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-gold text-gold-foreground hover:bg-gold/90 font-semibold px-12 py-6 text-lg rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300"
            >
              Contact Partnership Team
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              className="border-gold text-gold hover:bg-gold hover:text-gold-foreground font-semibold px-12 py-6 text-lg rounded-xl transition-all duration-300"
            >
              Download Partnership Guide
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default PartnerWithUs;