import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { ArrowRight, Package, Truck, FileCheck, Globe, Clock, Shield } from "lucide-react";

const StartTrading = () => {
  const steps = [
    {
      step: "01",
      icon: FileCheck,
      title: "Initial Consultation",
      description: "Schedule a consultation to discuss your trading needs, target markets, and product requirements."
    },
    {
      step: "02",
      icon: Package,
      title: "Product Selection",
      description: "Choose from our premium range of spices, textiles, and jewellery or request custom sourcing."
    },
    {
      step: "03",
      icon: Shield,
      title: "Quality Assurance",
      description: "Our team ensures all products meet international quality standards and regulatory requirements."
    },
    {
      step: "04",
      icon: Truck,
      title: "Logistics & Shipping",
      description: "We handle all logistics, customs clearance, and shipping to ensure timely delivery."
    }
  ];

  const services = [
    {
      icon: Globe,
      title: "Global Market Access",
      description: "Access to established trade networks across UK, Europe, Middle East, and Asia-Pacific regions.",
      features: ["Market entry support", "Local partner connections", "Regulatory guidance"]
    },
    {
      icon: Package,
      title: "Premium Product Portfolio",
      description: "Carefully curated selection of authentic Indian products with proven international demand.",
      features: ["Certified organic spices", "Luxury handwoven textiles", "Traditional jewellery collections"]
    },
    {
      icon: Clock,
      title: "End-to-End Support",
      description: "Complete trade support from sourcing to delivery with dedicated account management.",
      features: ["24/7 customer support", "Real-time shipment tracking", "Quality guarantees"]
    }
  ];

  const offices = [
    {
      location: "London Office",
      flag: "🇬🇧",
      address: "10 Royal Crescent, Ilford, London, IG2 7NH",
      phone: "+44 7532624042",
      email: "london@nivoraglobal.com",
      role: "European Operations Hub"
    },
    {
      location: "India Office",
      flag: "🇮🇳",
      address: "Thareparambil, Thalayazham P O, Vaikom, Kerala",
      phone: "+91 9446205777",
      email: "india@nivoraglobal.com",
      role: "Sourcing & Production Center"
    }
  ];

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Hero Section */}
      <section className="py-32 bg-primary text-white">
        <div className="container mx-auto px-6 lg:px-8 text-center">
          <h1 className="font-roboto text-5xl md:text-7xl font-bold mb-6 tracking-tight">
            Start Trading <span className="text-gold">Today</span>
          </h1>
          <div className="w-32 h-1 bg-gold mx-auto mb-6"></div>
          <p className="font-inter text-xl text-white/80 max-w-3xl mx-auto mb-12">
            Begin your journey into international trade with authentic Indian products and expert support
          </p>
          <Button 
            size="lg" 
            className="bg-gold text-gold-foreground hover:bg-gold/90 font-semibold px-12 py-6 text-lg rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300"
          >
            <ArrowRight className="mr-2 h-5 w-5" />
            Get Started Now
          </Button>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-32 bg-background">
        <div className="container mx-auto px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="font-roboto text-5xl md:text-6xl font-bold text-primary mb-6 tracking-tight">
              How It Works
            </h2>
            <div className="w-32 h-1 bg-gold mx-auto mb-6"></div>
            <p className="font-inter text-xl text-secondary max-w-3xl mx-auto">
              Simple steps to start your international trading journey with Nivora Global
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
            {steps.map((step, index) => (
              <div key={index} className="text-center group">
                <div className="relative mb-6">
                  <div className="w-20 h-20 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-gold/20 transition-all duration-300">
                    <step.icon className="h-10 w-10 text-gold" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 bg-gold rounded-full flex items-center justify-center text-white font-bold text-sm">
                    {step.step}
                  </div>
                </div>
                <h3 className="font-roboto text-xl font-bold text-primary mb-4">
                  {step.title}
                </h3>
                <p className="font-inter text-secondary leading-relaxed text-sm">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-32 bg-primary text-white">
        <div className="container mx-auto px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="font-roboto text-5xl md:text-6xl font-bold mb-6 tracking-tight">
              Our Trading Services
            </h2>
            <div className="w-32 h-1 bg-gold mx-auto mb-6"></div>
            <p className="font-inter text-xl text-white/80 max-w-3xl mx-auto">
              Comprehensive trading solutions designed to accelerate your business growth
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {services.map((service, index) => (
              <div key={index} className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20 hover:bg-white/20 transition-all duration-300">
                <div className="w-16 h-16 bg-gold/20 rounded-xl flex items-center justify-center mb-6">
                  <service.icon className="h-8 w-8 text-gold" />
                </div>
                <h3 className="font-roboto text-2xl font-bold text-gold mb-4">
                  {service.title}
                </h3>
                <p className="font-inter text-white/90 mb-6 leading-relaxed">
                  {service.description}
                </p>
                <div className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-gold rounded-full"></div>
                      <span className="font-inter text-white/80 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Offices */}
      <section className="py-32 bg-background">
        <div className="container mx-auto px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="font-roboto text-5xl md:text-6xl font-bold text-primary mb-6 tracking-tight">
              Get In Touch
            </h2>
            <div className="w-32 h-1 bg-gold mx-auto mb-6"></div>
            <p className="font-inter text-xl text-secondary max-w-3xl mx-auto">
              Contact our offices worldwide to start your trading journey
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-16">
            {offices.map((office, index) => (
              <div key={index} className="bg-white rounded-2xl p-8 shadow-lg border border-border hover:shadow-xl transition-all duration-300">
                <div className="flex items-center space-x-4 mb-6">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-gold to-gold/80 flex items-center justify-center text-3xl shadow-lg">
                    {office.flag}
                  </div>
                  <div>
                    <h3 className="font-roboto text-xl font-bold text-primary">{office.location}</h3>
                    <p className="font-inter text-secondary text-sm">{office.role}</p>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="text-gold">📍</div>
                    <p className="font-inter text-secondary text-sm leading-relaxed">
                      {office.address}
                    </p>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <div className="text-gold">📞</div>
                    <p className="font-inter text-primary font-medium">{office.phone}</p>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <div className="text-gold">📧</div>
                    <p className="font-inter text-primary">{office.email}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center">
            <Button 
              size="lg" 
              className="bg-gold text-gold-foreground hover:bg-gold/90 font-semibold px-12 py-6 text-lg rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300"
            >
              <ArrowRight className="mr-2 h-5 w-5" />
              Schedule Consultation
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default StartTrading;