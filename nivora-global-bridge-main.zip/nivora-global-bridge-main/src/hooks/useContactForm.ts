import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface ContactFormData {
  name: string;
  contact_number: string;
  email: string;
  message: string;
}

export const useContactForm = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    contact_number: '',
    email: '',
    message: ''
  });

  const resetForm = () => {
    setFormData({
      name: '',
      contact_number: '',
      email: '',
      message: ''
    });
  };

  const validateForm = (data: ContactFormData): string | null => {
    if (!data.name.trim()) return 'Name is required';
    if (!data.contact_number.trim()) return 'Contact number is required';
    if (!data.email.trim()) return 'Email is required';
    if (!data.message.trim()) return 'Message is required';

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) return 'Please enter a valid email address';

    // Phone number basic validation
    const phoneRegex = /^[\+]?[0-9\s\-\(\)]+$/;
    if (!phoneRegex.test(data.contact_number)) return 'Please enter a valid contact number';

    return null;
  };

  const submitForm = async (data: ContactFormData, recaptchaToken?: string) => {
    setIsSubmitting(true);

    try {
      // Validate form data
      const validationError = validateForm(data);
      if (validationError) {
        toast.error(validationError);
        return false;
      }

      // Call the edge function
      const { data: response, error } = await supabase.functions.invoke('contact-form', {
        body: {
          ...data,
          recaptcha_token: recaptchaToken
        }
      });

      if (error) {
        console.error('Contact form error:', error);
        toast.error('Failed to send message. Please try again.');
        return false;
      }

      if (response?.success) {
        toast.success(response.message || 'Thank you for contacting us. Our team will get back to you soon.');
        resetForm();
        return true;
      } else {
        toast.error(response?.error || 'An error occurred. Please try again.');
        return false;
      }
    } catch (error) {
      console.error('Submit error:', error);
      toast.error('An unexpected error occurred. Please try again.');
      return false;
    } finally {
      setIsSubmitting(false);
    }
  };

  return {
    formData,
    setFormData,
    isSubmitting,
    submitForm,
    resetForm,
    validateForm
  };
};